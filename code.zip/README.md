# simple-flask
Simple Flask application to test ECS Blue/Green deployment
